# Dock Events: data and model credits

- Data: Forklift Object Detection (keremberke mirror on Hugging Face; original on Roboflow Public, exported from images.cv) (https://huggingface.co/datasets/keremberke/forklift-object-detection)
- Attribution: Forklift Object Detection dataset (421 images, forklift and person), exported from images.cv via Roboflow Public and mirrored on Hugging Face at keremberke/forklift-object-detection. Licensed CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Changes: merged the train and valid splits, subset to 150 images, converted to CVAT rectangle format, and added an illustrative dock_activity scene tag by rule.
- License: CC BY 4.0
- Pre-label model: YOLO v7. Pre-trained only; nothing was trained on these images.